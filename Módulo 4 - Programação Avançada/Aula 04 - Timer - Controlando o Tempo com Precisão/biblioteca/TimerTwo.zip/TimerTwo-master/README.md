# TimerTwo
Arduino Timer2 library
